//
//  Constants.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/8/23.
//

import Foundation

struct K {
    
    struct GetterName {
        static let getterName = "Getter."
    }
    
}
