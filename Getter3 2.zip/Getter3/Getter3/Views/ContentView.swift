//
//  ContentView.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/5/23.
//

import SwiftUI
//import Constants

struct ContentView: View {
    //default selected view
    @State private var tabSelected: Tab = .clipboard
    
    //class initialization
    init() {
        UITabBar.appearance().isHidden = true
    }
    
    //TabView logic
    var body: some View {
            //changed NavView to hstack
            ZStack {
                VStack {
                    TabView(selection: $tabSelected) {
                        ForEach(Tab.allCases, id: \.self) { tab in
                            getView(for: tab)
                                .tag(tab)
                        }
                    }
                    
                    VStack {
                        //Spacer()
                        CustomTabBar(selectedTab: $tabSelected)
                    }//end of VStack
                    
                }//end of VStack
                
            }//end of ZStack
    }
    
    //different screens
    private func getView(for tab: Tab) -> some View {
        switch tab {
        case .calendar:
            return AnyView(CalendarView())
        case .clipboard:
            return AnyView(ListView())
        case .person:
            return AnyView(NewEventView())
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
