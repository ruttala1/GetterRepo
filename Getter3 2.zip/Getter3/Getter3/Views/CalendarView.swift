//
//  CalendarView.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/8/23.
//

import SwiftUI

struct CalendarView: View {
    var body: some View {
        Text("calendar")
    }
}

struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}
