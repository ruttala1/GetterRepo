//
//  NewEventView.swift
//  Getter3
//
//  Created by Rohin Joshi on 4/5/23.
//

import SwiftUI

struct NewEventView: View {
    @State var newEventString: String = ""
    @State var notesEventString: String = ""
    @State var selectedStartDate: Date = Date()
    @State var selectedEndDate: Date = Date()
    
    var body: some View {
        
        VStack{
            //heading
            HStack{
                Text(K.GetterName.getterName)
                    .font(.system(size:43, weight: .bold))
                    .padding(.leading, -175)
            }
            ScrollView{
                
                    VStack{
                        
                        Text("New Item")
                            .font(.system(size:23, weight:.bold))
                            .padding(.leading, -175)
                            
                        VStack{
                            TextField("New Event", text: $newEventString)
                                .padding()
                                .background(Color.gray.opacity(0.23).cornerRadius(10))
                        }
                        .padding(.horizontal)

                        
                        VStack{
                            TextField("Notes", text: $notesEventString)
                                .padding()
                                .background(Color.gray.opacity(0.23).cornerRadius(10))
                        }
                        .padding(.horizontal)

                        DatePicker("Start Date", selection: $selectedStartDate)
                                          .padding(.horizontal)
                        
                        DatePicker("Due Date", selection: $selectedEndDate)
                                          .padding(.horizontal)
                }
                
            }
        }
    }
}

struct NewEventView_Previews: PreviewProvider {
    static var previews: some View {
        NewEventView()
    }
}
